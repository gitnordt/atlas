//>>built
define("dijit/nls/cs/loading",({loadingState:"Probíhá načítání...",errorState:"Omlouváme se, došlo k chybě"}));
